package service;

import model.Empleado;
import qualifier.Comision;
import javax.enterprise.context.Dependent;
import java.io.Serializable;

@Dependent
@Comision
public class SalarioComisionCalculator implements CalculadorSalario, Serializable {

    @Override
    public double calcular(Empleado empleado) {
        return empleado.getSalarioBase() + empleado.getComision();
    }
}