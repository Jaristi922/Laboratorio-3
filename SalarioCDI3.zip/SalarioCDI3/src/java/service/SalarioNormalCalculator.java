package service;

import model.Empleado;
import qualifier.Normal;
import javax.enterprise.context.Dependent;
import java.io.Serializable;

@Dependent
@Normal
public class SalarioNormalCalculator implements CalculadorSalario, Serializable {

    @Override
    public double calcular(Empleado empleado) {
        return empleado.getSalarioBase();
    }
}