package service;

import model.Empleado;
import qualifier.HorasExtras;
import javax.enterprise.context.Dependent;
import java.io.Serializable;

@Dependent
@HorasExtras
public class SalarioHorasExtrasCalculator implements CalculadorSalario, Serializable {

    @Override
    public double calcular(Empleado empleado) {
        double pagoExtras = empleado.getHorasExtras() * empleado.getValorHoraExtra();
        return empleado.getSalarioBase() + pagoExtras;
    }
}