package view;

import model.Empleado;
import service.CalculadorSalario;
import qualifier.Normal;
import qualifier.HorasExtras;
import qualifier.Comision;

import javax.inject.Inject;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named(value = "empleadoBean")
@SessionScoped
public class EmpleadoBean implements Serializable {

    @Inject
    @Normal
    private CalculadorSalario calculadorNormal;

    @Inject
    @HorasExtras
    private CalculadorSalario calculadorHorasExtras;

    @Inject
    @Comision
    private CalculadorSalario calculadorComision;

    private String id;
    private String nombre;
    private double salarioBase;

    private boolean aplicaHorasExtras;
    private double numeroHorasExtras;
    private double valorHoraExtra;

    private boolean aplicaComision;
    private double valorComision;

    private List<Empleado> empleados;

    @PostConstruct
    public void init() {
        empleados = new ArrayList<>();
        System.out.println("EmpleadoBean inicializado (@PostConstruct).");
    }

    @PreDestroy
    public void destroy() {
        System.out.println("EmpleadoBean destruido (@PreDestroy).");
    }

    public String insertar() {
        Empleado empleado = new Empleado();
        empleado.setId(id);
        empleado.setNombre(nombre);
        empleado.setSalarioBase(salarioBase);

        double salarioFinal;

        if (aplicaHorasExtras) {
            empleado.setHorasExtras(numeroHorasExtras);
            empleado.setValorHoraExtra(valorHoraExtra);
            salarioFinal = calculadorHorasExtras.calcular(empleado);
        } else if (aplicaComision) {
            empleado.setComision(valorComision);
            salarioFinal = calculadorComision.calcular(empleado);
        } else {
            salarioFinal = calculadorNormal.calcular(empleado);
        }

        empleado.setSalarioFinal(salarioFinal);
        empleados.add(empleado);

        limpiarFormulario();
        return null;
    }

    private void limpiarFormulario() {
        id = null;
        nombre = null;
        salarioBase = 0;
        aplicaHorasExtras = false;
        numeroHorasExtras = 0;
        valorHoraExtra = 0;
        aplicaComision = false;
        valorComision = 0;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

    public boolean isAplicaHorasExtras() {
        return aplicaHorasExtras;
    }

    public void setAplicaHorasExtras(boolean aplicaHorasExtras) {
        this.aplicaHorasExtras = aplicaHorasExtras;
    }

    public double getNumeroHorasExtras() {
        return numeroHorasExtras;
    }

    public void setNumeroHorasExtras(double numeroHorasExtras) {
        this.numeroHorasExtras = numeroHorasExtras;
    }

    public double getValorHoraExtra() {
        return valorHoraExtra;
    }

    public void setValorHoraExtra(double valorHoraExtra) {
        this.valorHoraExtra = valorHoraExtra;
    }

    public boolean isAplicaComision() {
        return aplicaComision;
    }

    public void setAplicaComision(boolean aplicaComision) {
        this.aplicaComision = aplicaComision;
    }

    public double getValorComision() {
        return valorComision;
    }

    public void setValorComision(double valorComision) {
        this.valorComision = valorComision;
    }

    public List<Empleado> getEmpleados() {
        return empleados;
    }
}