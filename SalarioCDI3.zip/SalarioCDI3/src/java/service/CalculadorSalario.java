package service;

import model.Empleado;

public interface CalculadorSalario {

    double calcular(Empleado empleado);

}